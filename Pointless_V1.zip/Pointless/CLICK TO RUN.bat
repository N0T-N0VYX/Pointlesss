@echo off
python "C:\Users\notno\OneDrive\Documents\Pointless\hand_mouse.py"
pause

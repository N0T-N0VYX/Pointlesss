import sys
import time
import math
import threading

import cv2
import mediapipe as mp
import pyautogui

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QImage, QPixmap, QShortcut, QKeySequence
from PySide6.QtWidgets import (
    QApplication,
    QWidget,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QFrame,
    QSlider,
    QProgressBar,
    QSizePolicy,
    QScrollArea,
)


# ============================================================
# POINTLESS
# Pixel / Material 3 Expressive inspired UI
# ============================================================

SCREEN_W, SCREEN_H = pyautogui.size()

pyautogui.PAUSE = 0
pyautogui.MINIMUM_DURATION = 0

CURSOR_HZ = 144


# ============================================================
# HELPERS
# ============================================================

def clamp(v, low, high):
    return max(low, min(high, v))


def dist3(a, b):
    return math.sqrt(
        (a.x - b.x) ** 2 +
        (a.y - b.y) ** 2 +
        (a.z - b.z) ** 2
    )


def angle3(a, b, c):
    ba = (
        a.x - b.x,
        a.y - b.y,
        a.z - b.z
    )

    bc = (
        c.x - b.x,
        c.y - b.y,
        c.z - b.z
    )

    dot = sum(
        ba[i] * bc[i]
        for i in range(3)
    )

    ma = math.sqrt(
        sum(v * v for v in ba)
    )

    mc = math.sqrt(
        sum(v * v for v in bc)
    )

    if ma == 0 or mc == 0:
        return 0

    value = clamp(
        dot / (ma * mc),
        -1,
        1
    )

    return math.degrees(
        math.acos(value)
    )


# ============================================================
# CURSOR ENGINE
# ============================================================

class CursorEngine(QThread):

    def __init__(self):
        super().__init__()

        self.running = True
        self.enabled = False

        self.target_x = 0.0
        self.target_y = 0.0

        self.velocity_x = 0.0
        self.velocity_y = 0.0

        self.speed = 100
        self.precision = 70
        self.smoothing = 20
        self.acceleration = 50
        self.dead_zone = 15

        self.lock = threading.Lock()

        try:
            x, y = pyautogui.position()
        except Exception:
            x = SCREEN_W // 2
            y = SCREEN_H // 2

        self.x = float(x)
        self.y = float(y)

    def set_enabled(self, enabled):

        with self.lock:

            self.enabled = enabled

            if not enabled:

                self.target_x = 0
                self.target_y = 0
                self.velocity_x = 0
                self.velocity_y = 0

    def set_target(self, x, y):

        with self.lock:

            if self.enabled:

                self.target_x = x
                self.target_y = y

            else:

                self.target_x = 0
                self.target_y = 0

    def update_settings(
        self,
        speed,
        precision,
        smoothing,
        acceleration,
        dead_zone
    ):

        with self.lock:

            self.speed = speed
            self.precision = precision
            self.smoothing = smoothing
            self.acceleration = acceleration
            self.dead_zone = dead_zone

    def stop_engine(self):

        self.running = False

    def run(self):

        frame_dt = 1.0 / CURSOR_HZ
        previous = time.perf_counter()

        while self.running:

            started = time.perf_counter()

            now = time.perf_counter()

            dt = clamp(
                now - previous,
                0.001,
                0.03
            )

            previous = now

            with self.lock:

                enabled = self.enabled

                target_x = self.target_x
                target_y = self.target_y

                speed = self.speed
                precision = self.precision
                smoothing = self.smoothing
                acceleration = self.acceleration

            if not enabled:

                target_x = 0
                target_y = 0

            # ------------------------------------------------
            # SPEED
            # ------------------------------------------------

            speed_multiplier = (
                0.25 +
                (speed / 100.0) * 3.75
            )

            precision_multiplier = (
                0.35 +
                (precision / 100.0) * 0.65
            )

            target_x *= (
                speed_multiplier *
                precision_multiplier
            )

            target_y *= (
                speed_multiplier *
                precision_multiplier
            )

            # ------------------------------------------------
            # ACCELERATION
            # ------------------------------------------------

            accel = (
                10 +
                acceleration * 0.35
            )

            response = clamp(
                accel * dt,
                0,
                1
            )

            self.velocity_x += (
                target_x -
                self.velocity_x
            ) * response

            self.velocity_y += (
                target_y -
                self.velocity_y
            ) * response

            # ------------------------------------------------
            # SMOOTHING
            # ------------------------------------------------

            smoothing_amount = (
                smoothing / 100
            )

            damping = (
                1.0 -
                smoothing_amount * 0.08
            )

            self.velocity_x *= damping
            self.velocity_y *= damping

            # ------------------------------------------------
            # MOVE
            # ------------------------------------------------

            if enabled:

                self.x += (
                    self.velocity_x * dt
                )

                self.y += (
                    self.velocity_y * dt
                )

                self.x = clamp(
                    self.x,
                    1,
                    SCREEN_W - 1
                )

                self.y = clamp(
                    self.y,
                    1,
                    SCREEN_H - 1
                )

                try:

                    pyautogui.moveTo(
                        round(self.x),
                        round(self.y),
                        _pause=False
                    )

                except Exception:
                    pass

            elapsed = (
                time.perf_counter() -
                started
            )

            remaining = (
                frame_dt -
                elapsed
            )

            if remaining > 0:
                time.sleep(remaining)


# ============================================================
# CAMERA / GESTURE ENGINE
# ============================================================

class CameraThread(QThread):

    frame_ready = Signal(QImage)
    state_changed = Signal(dict)

    def __init__(self):

        super().__init__()

        self.running = True
        self.enabled = False

        self.mp_hands = mp.solutions.hands
        self.mp_draw = mp.solutions.drawing_utils

        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=1,
            model_complexity=1,
            min_detection_confidence=0.70,
            min_tracking_confidence=0.70
        )

        self.cap = cv2.VideoCapture(0)

        self.cap.set(
            cv2.CAP_PROP_FRAME_WIDTH,
            640
        )

        self.cap.set(
            cv2.CAP_PROP_FRAME_HEIGHT,
            480
        )

        self.cap.set(
            cv2.CAP_PROP_FPS,
            60
        )

        self.cursor = CursorEngine()
        self.cursor.start()

        # ----------------------------------------------------
        # SETTINGS
        # ----------------------------------------------------

        self.speed = 100
        self.precision = 70
        self.smoothing = 20
        self.acceleration = 50
        self.dead_zone = 15

        # ----------------------------------------------------
        # MOVEMENT
        # ----------------------------------------------------

        self.last_x = None
        self.last_y = None
        self.last_time = None

        self.vx = 0
        self.vy = 0

        self.hand_speed = 0
        self.direction = "IDLE"
        self.angle = 0

        # ----------------------------------------------------
        # GESTURE
        # ----------------------------------------------------

        self.candidate = "NONE"
        self.candidate_frames = 0
        self.gesture = "NONE"

        self.STABILITY = 4

        self.last_click = 0
        self.CLICK_COOLDOWN = 0.50

        self.dragging = False

    # ========================================================
    # SETTINGS
    # ========================================================

    def update_settings(
        self,
        speed,
        precision,
        smoothing,
        acceleration,
        dead_zone
    ):

        self.speed = speed
        self.precision = precision
        self.smoothing = smoothing
        self.acceleration = acceleration
        self.dead_zone = dead_zone

        self.cursor.update_settings(
            speed,
            precision,
            smoothing,
            acceleration,
            dead_zone
        )

    # ========================================================
    # ENABLE
    # ========================================================

    def set_control(self, enabled):

        self.enabled = enabled

        self.cursor.set_enabled(
            enabled
        )

        if not enabled:

            self.cursor.set_target(
                0,
                0
            )

            if self.dragging:

                try:
                    pyautogui.mouseUp(
                        button="left"
                    )
                except Exception:
                    pass

                self.dragging = False

    # ========================================================
    # FINGER DETECTION
    # ========================================================

    def finger_extended(
        self,
        lm,
        mcp,
        pip,
        tip
    ):

        angle = angle3(
            lm[mcp],
            lm[pip],
            lm[tip]
        )

        tip_distance = dist3(
            lm[tip],
            lm[0]
        )

        pip_distance = dist3(
            lm[pip],
            lm[0]
        )

        return (
            angle > 150 and
            tip_distance >
            pip_distance * 1.04
        )

    def thumb_extended(self, lm):

        angle = angle3(
            lm[2],
            lm[3],
            lm[4]
        )

        tip_to_pinky = dist3(
            lm[4],
            lm[17]
        )

        ip_to_pinky = dist3(
            lm[3],
            lm[17]
        )

        return (
            angle > 140 and
            tip_to_pinky >
            ip_to_pinky * 1.06
        )

    def pinch(self, lm):

        palm = dist3(
            lm[0],
            lm[9]
        )

        if palm < 0.001:
            return False

        pinch_distance = dist3(
            lm[4],
            lm[8]
        )

        return (
            pinch_distance / palm
        ) < 0.34

    # ========================================================
    # GESTURE RECOGNITION
    # ========================================================

    def detect_gesture(self, lm):

        thumb = self.thumb_extended(lm)

        index = self.finger_extended(
            lm, 5, 6, 8
        )

        middle = self.finger_extended(
            lm, 9, 10, 12
        )

        ring = self.finger_extended(
            lm, 13, 14, 16
        )

        pinky = self.finger_extended(
            lm, 17, 18, 20
        )

        # Pinch
        if self.pinch(lm):
            return "DRAG"

        # Fist
        if not any([
            thumb,
            index,
            middle,
            ring,
            pinky
        ]):
            return "PAUSE"

        # Open hand
        if all([
            thumb,
            index,
            middle,
            ring,
            pinky
        ]):
            return "RESUME"

        # Two fingers
        if (
            index and
            middle and
            not ring and
            not pinky
        ):
            return "SCROLL"

        # Index
        if (
            index and
            not middle and
            not ring and
            not pinky
        ):
            return "MOVE"

        # Thumb
        if (
            thumb and
            not index and
            not middle and
            not ring and
            not pinky
        ):
            return "LEFT CLICK"

        # Pinky
        if (
            pinky and
            not thumb and
            not index and
            not middle and
            not ring
        ):
            return "RIGHT CLICK"

        return "NONE"

    # ========================================================
    # STABILITY
    # ========================================================

    def stabilize(self, raw):

        if raw == self.candidate:

            self.candidate_frames += 1

        else:

            self.candidate = raw
            self.candidate_frames = 1

        if (
            self.candidate_frames >=
            self.STABILITY
        ):

            self.gesture = raw

        return self.gesture

    # ========================================================
    # MOVEMENT
    # ========================================================

    def update_movement(
        self,
        hand_x,
        hand_y,
        now
    ):

        if self.last_x is None:

            self.last_x = hand_x
            self.last_y = hand_y
            self.last_time = now

            return

        dt = now - self.last_time

        if dt <= 0:
            return

        # ----------------------------------------------------
        # IMPORTANT:
        #
        # MediaPipe x:
        #   hand right = x increases
        #
        # MediaPipe y:
        #   hand down = y increases
        #
        # We DO NOT invert either axis.
        #
        # Camera is already mirrored with cv2.flip().
        # ----------------------------------------------------

        dx = hand_x - self.last_x
        dy = hand_y - self.last_y

        self.last_x = hand_x
        self.last_y = hand_y
        self.last_time = now

        vx = dx / dt
        vy = dy / dt

        # ----------------------------------------------------
        # DEAD ZONE
        # ----------------------------------------------------

        magnitude = math.sqrt(
            vx * vx +
            vy * vy
        )

        threshold = (
            0.035 +
            self.dead_zone * 0.0011
        )

        if magnitude < threshold:

            vx = 0
            vy = 0

        # ----------------------------------------------------
        # SMOOTHING
        # ----------------------------------------------------

        smoothing = (
            self.smoothing / 100
        )

        alpha = (
            0.88 -
            smoothing * 0.48
        )

        self.vx += (
            vx - self.vx
        ) * alpha

        self.vy += (
            vy - self.vy
        ) * alpha

        self.hand_speed = math.sqrt(
            self.vx ** 2 +
            self.vy ** 2
        )

        # ----------------------------------------------------
        # DIRECTION
        # ----------------------------------------------------

        speed = self.hand_speed

        if speed < 0.025:

            self.direction = "IDLE"
            self.angle = 0

        else:

            # SCREEN coordinates:
            # right = +
            # down  = +
            #
            # Therefore this angle is based directly
            # on the actual cursor direction.

            self.angle = (
                math.degrees(
                    math.atan2(
                        self.vy,
                        self.vx
                    )
                ) % 360
            )

            directions = [
                (0, "RIGHT"),
                (45, "DOWN-RIGHT"),
                (90, "DOWN"),
                (135, "DOWN-LEFT"),
                (180, "LEFT"),
                (225, "UP-LEFT"),
                (270, "UP"),
                (315, "UP-RIGHT"),
            ]

            self.direction = min(
                directions,
                key=lambda item:
                abs(
                    (
                        self.angle -
                        item[0] +
                        180
                    ) % 360 - 180
                )
            )[1]

        # ----------------------------------------------------
        # SPEED
        # ----------------------------------------------------

        speed_multiplier = (
            0.25 +
            self.speed / 100 * 3.75
        )

        precision_multiplier = (
            0.35 +
            self.precision / 100 * 0.65
        )

        acceleration_boost = (
            1.0 +
            min(speed, 2.0) *
            (self.acceleration / 100) *
            1.7
        )

        final_scale = (
            1450 *
            speed_multiplier *
            precision_multiplier *
            acceleration_boost
        )

        final_x = (
            self.vx *
            final_scale
        )

        final_y = (
            self.vy *
            final_scale
        )

        final_x = clamp(
            final_x,
            -10000,
            10000
        )

        final_y = clamp(
            final_y,
            -10000,
            10000
        )

        self.cursor.set_target(
            final_x,
            final_y
        )

    # ========================================================
    # ACTIONS
    # ========================================================

    def action(self, gesture):

        now = time.perf_counter()

        if gesture == "PAUSE":

            self.cursor.set_target(
                0,
                0
            )

            if self.dragging:

                try:
                    pyautogui.mouseUp(
                        button="left"
                    )
                except Exception:
                    pass

                self.dragging = False

            return

        if gesture == "RESUME":

            self.cursor.set_target(
                0,
                0
            )

            return

        if gesture == "DRAG":

            if not self.dragging:

                try:

                    pyautogui.mouseDown(
                        button="left"
                    )

                    self.dragging = True

                except Exception:
                    pass

            return

        if self.dragging:

            try:
                pyautogui.mouseUp(
                    button="left"
                )
            except Exception:
                pass

            self.dragging = False

        if (
            now -
            self.last_click <
            self.CLICK_COOLDOWN
        ):
            return

        if gesture == "LEFT CLICK":

            try:
                pyautogui.click(
                    button="left"
                )
            except Exception:
                pass

            self.last_click = now

        elif gesture == "RIGHT CLICK":

            try:
                pyautogui.click(
                    button="right"
                )
            except Exception:
                pass

            self.last_click = now

    # ========================================================
    # SCROLL
    # ========================================================

    def scroll(self):

        amount = self.vy * 12

        if abs(amount) < 0.2:
            return

        amount = int(
            clamp(
                amount,
                -10,
                10
            )
        )

        if amount:

            try:
                pyautogui.scroll(
                    amount
                )
            except Exception:
                pass

    # ========================================================
    # CAMERA LOOP
    # ========================================================

    def run(self):

        while self.running:

            ok, frame = self.cap.read()

            if not ok:
                continue

            frame = cv2.flip(
                frame,
                1
            )

            rgb = cv2.cvtColor(
                frame,
                cv2.COLOR_BGR2RGB
            )

            result = self.hands.process(
                rgb
            )

            gesture = "NONE"
            confidence = 0

            if result.multi_hand_landmarks:

                hand = result.multi_hand_landmarks[0]

                lm = hand.landmark

                now = time.perf_counter()

                if self.enabled:

                    self.update_movement(
                        lm[0].x,
                        lm[0].y,
                        now
                    )

                else:

                    self.cursor.set_target(
                        0,
                        0
                    )

                raw = self.detect_gesture(
                    lm
                )

                gesture = self.stabilize(
                    raw
                )

                confidence = min(
                    100,
                    int(
                        self.candidate_frames /
                        self.STABILITY *
                        100
                    )
                )

                if self.enabled:

                    if gesture == "MOVE":
                        pass

                    elif gesture == "SCROLL":
                        self.scroll()

                    else:
                        self.action(
                            gesture
                        )

                self.mp_draw.draw_landmarks(
                    frame,
                    hand,
                    self.mp_hands.HAND_CONNECTIONS
                )

            else:

                self.cursor.set_target(
                    0,
                    0
                )

                self.last_x = None
                self.last_y = None
                self.last_time = None

                self.vx = 0
                self.vy = 0

                self.hand_speed = 0
                self.direction = "IDLE"
                self.angle = 0

            # ------------------------------------------------
            # Camera overlay
            # ------------------------------------------------

            text = (
                "GESTURE CONTROL  •  ON"
                if self.enabled
                else
                "GESTURE CONTROL  •  OFF"
            )

            cv2.putText(
                frame,
                text,
                (18, 32),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (225, 220, 235),
                2
            )

            cv2.putText(
                frame,
                gesture,
                (18, 65),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.72,
                (255, 255, 255),
                2
            )

            # ------------------------------------------------
            # Qt
            # ------------------------------------------------

            rgb_frame = cv2.cvtColor(
                frame,
                cv2.COLOR_BGR2RGB
            )

            h, w, ch = rgb_frame.shape

            image = QImage(
                rgb_frame.data,
                w,
                h,
                ch * w,
                QImage.Format_RGB888
            )

            self.frame_ready.emit(
                image.copy()
            )

            self.state_changed.emit({
                "enabled": self.enabled,
                "gesture": gesture,
                "confidence": confidence,
                "speed": self.hand_speed,
                "direction": self.direction,
                "angle": self.angle
            })

        self.cap.release()
        self.hands.close()

        self.cursor.stop_engine()
        self.cursor.wait()


# ============================================================
# MATERIAL 3 EXPRESSIVE UI
# ============================================================

class PointlessUI(QWidget):

    def __init__(self):

        super().__init__()

        self.setWindowTitle(
            "Pointless"
        )

        self.resize(
            1500,
            780
        )

        self.setMinimumSize(
            1100,
            650
        )

        self.setAutoFillBackground(False)

        self.camera = CameraThread()

        self.build_ui()

        self.camera.frame_ready.connect(
            self.update_camera
        )

        self.camera.state_changed.connect(
            self.update_state
        )

        self.camera.start()

    # ========================================================
    # UI
    # ========================================================

    def build_ui(self):

        self.setStyleSheet("""

        /* =========================================================
           POINTLESS • LIQUID GLASS
           Visual layer only. Functionality remains unchanged.
           ========================================================= */

        QWidget {
            color: #F7F4FA;
            font-family: "Segoe UI";
            background: transparent;
        }

        QFrame#TopSurface {
            background: qlineargradient(
                x1: 0, y1: 0,
                x2: 1, y2: 1,
                stop: 0 rgba(255, 255, 255, 26),
                stop: 0.45 rgba(255, 255, 255, 10),
                stop: 1 rgba(120, 85, 170, 18)
            );
            border: 1px solid rgba(255, 255, 255, 34);
            border-radius: 28px;
        }

        QFrame#Surface {
            background: qlineargradient(
                x1: 0, y1: 0,
                x2: 1, y2: 1,
                stop: 0 rgba(255, 255, 255, 22),
                stop: 0.5 rgba(255, 255, 255, 8),
                stop: 1 rgba(110, 75, 145, 14)
            );
            border: 1px solid rgba(255, 255, 255, 28);
            border-radius: 24px;
        }

        QFrame#Surface:hover {
            border: 1px solid rgba(255, 255, 255, 42);
        }

        QFrame#CameraSurface {
            background: rgba(7, 7, 10, 218);
            border: 1px solid rgba(255, 255, 255, 30);
            border-radius: 32px;
        }

        QLabel#Title {
            font-size: 31px;
            font-weight: 800;
            color: #FFFFFF;
        }

        QLabel#Subtitle {
            font-size: 14px;
            color: rgba(235, 228, 242, 190);
        }

        QLabel#Headline {
            font-size: 27px;
            font-weight: 800;
            color: #FFFFFF;
        }

        QLabel#Section {
            font-size: 12px;
            font-weight: 800;
            color: rgba(230, 221, 240, 175);
        }

        QLabel#Value {
            font-size: 25px;
            font-weight: 800;
            color: #FFFFFF;
        }

        QLabel#Muted {
            font-size: 12px;
            color: rgba(220, 211, 228, 155);
        }

        QLabel#Status {
            background: rgba(130, 95, 170, 58);
            color: #EBD9FF;
            border: 1px solid rgba(226, 195, 255, 48);
            border-radius: 18px;
            padding: 9px 15px;
            font-weight: 800;
        }

        QLabel#StatusOn {
            background: rgba(55, 150, 95, 62);
            color: #C7FFD9;
            border: 1px solid rgba(150, 255, 190, 58);
            border-radius: 18px;
            padding: 9px 15px;
            font-weight: 800;
        }

        QPushButton {
            background: qlineargradient(
                x1: 0, y1: 0,
                x2: 1, y2: 1,
                stop: 0 #F4E6FF,
                stop: 0.5 #E5C8FF,
                stop: 1 #D7B2F4
            );
            color: #261B30;
            border: 1px solid rgba(255, 255, 255, 86);
            border-radius: 19px;
            padding: 13px 22px;
            font-size: 13px;
            font-weight: 800;
        }

        QPushButton:hover {
            background: #F7ECFF;
            border: 1px solid rgba(255, 255, 255, 118);
        }

        QPushButton:pressed {
            background: #CFABE9;
        }

        QPushButton#Secondary {
            background: rgba(255, 255, 255, 16);
            color: #ECE6F0;
            border: 1px solid rgba(255, 255, 255, 32);
        }

        QPushButton#Secondary:hover {
            background: rgba(255, 255, 255, 27);
        }

        QSlider::groove:horizontal {
            height: 7px;
            background: rgba(255, 255, 255, 24);
            border: 1px solid rgba(255, 255, 255, 16);
            border-radius: 4px;
        }

        QSlider::sub-page:horizontal {
            background: qlineargradient(
                x1: 0, y1: 0,
                x2: 1, y2: 0,
                stop: 0 #B98CE0,
                stop: 1 #E6C7FF
            );
            border-radius: 4px;
        }

        QSlider::handle:horizontal {
            width: 20px;
            height: 20px;
            margin: -7px 0;
            background: #FFFFFF;
            border: 3px solid #D7AFE9;
            border-radius: 10px;
        }

        QSlider::handle:horizontal:hover {
            border: 3px solid #F0D9FF;
        }

        QProgressBar {
            background: rgba(255, 255, 255, 18);
            border: 1px solid rgba(255, 255, 255, 12);
            border-radius: 5px;
            height: 8px;
        }

        QProgressBar::chunk {
            background: qlineargradient(
                x1: 0, y1: 0,
                x2: 1, y2: 0,
                stop: 0 #B38BD2,
                stop: 1 #E4C4FF
            );
            border-radius: 5px;
        }

        """)

        root = QVBoxLayout(
            self
        )

        root.setContentsMargins(
            28,
            24,
            28,
            28
        )

        root.setSpacing(
            18
        )

        # ====================================================
        # HEADER
        # ====================================================

        header = QFrame()

        header.setObjectName(
            "TopSurface"
        )

        header_layout = QHBoxLayout(
            header
        )

        header_layout.setContentsMargins(
            24,
            18,
            20,
            18
        )

        text = QVBoxLayout()

        title = QLabel(
            "Pointless"
        )

        title.setObjectName(
            "Title"
        )

        subtitle = QLabel(
            "Gesture control"
        )

        subtitle.setObjectName(
            "Subtitle"
        )

        text.addWidget(title)
        text.addWidget(subtitle)

        header_layout.addLayout(
            text
        )

        header_layout.addStretch()

        self.status = QLabel(
            "●  OFF"
        )

        self.status.setObjectName(
            "Status"
        )

        header_layout.addWidget(
            self.status
        )

        root.addWidget(
            header
        )

        # ====================================================
        # MAIN CONTENT
        # ====================================================

        main = QHBoxLayout()

        main.setSpacing(
            18
        )

        # ====================================================
        # CAMERA
        # ====================================================

        camera_surface = QFrame()

        camera_surface.setObjectName(
            "CameraSurface"
        )

        camera_surface.setSizePolicy(
            QSizePolicy.Expanding,
            QSizePolicy.Expanding
        )

        camera_layout = QVBoxLayout(
            camera_surface
        )

        camera_layout.setContentsMargins(
            12,
            12,
            12,
            12
        )

        self.camera_view = QLabel()

        self.camera_view.setAlignment(
            Qt.AlignCenter
        )

        self.camera_view.setMinimumSize(
            0,
            0
        )

        self.camera_view.setSizePolicy(
            QSizePolicy.Expanding,
            QSizePolicy.Expanding
        )

        self.camera_view.setStyleSheet("""
            QLabel {
                background: rgba(5, 5, 8, 225);
                border: 1px solid rgba(255, 255, 255, 20);
                border-radius: 25px;
            }
        """)

        camera_layout.addWidget(
            self.camera_view
        )

        main.addWidget(
            camera_surface,
            7
        )

        # ====================================================
        # RIGHT PANEL
        # ====================================================

        side = QVBoxLayout()

        side.setSpacing(
            14
        )

        # ----------------------------------------------------
        # CURRENT GESTURE
        # ----------------------------------------------------

        gesture_card = QFrame()

        gesture_card.setObjectName(
            "Surface"
        )

        gesture_layout = QVBoxLayout(
            gesture_card
        )

        gesture_layout.setContentsMargins(
            20,
            20,
            20,
            20
        )

        label = QLabel(
            "CURRENT GESTURE"
        )

        label.setObjectName(
            "Section"
        )

        gesture_layout.addWidget(
            label
        )

        self.gesture_value = QLabel(
            "NONE"
        )

        self.gesture_value.setObjectName(
            "Value"
        )

        gesture_layout.addWidget(
            self.gesture_value
        )

        self.confidence_text = QLabel(
            "Stability  •  0%"
        )

        self.confidence_text.setObjectName(
            "Muted"
        )

        gesture_layout.addWidget(
            self.confidence_text
        )

        self.confidence = QProgressBar()

        gesture_layout.addWidget(
            self.confidence
        )

        gesture_card.setSizePolicy(
            QSizePolicy.Preferred,
            QSizePolicy.Fixed
        )

        side.addWidget(
            gesture_card
        )

        # ----------------------------------------------------
        # MOVEMENT
        # ----------------------------------------------------

        movement = QFrame()

        movement.setObjectName(
            "Surface"
        )

        movement_layout = QVBoxLayout(
            movement
        )

        movement_layout.setContentsMargins(
            20,
            20,
            20,
            20
        )

        section = QLabel(
            "MOVEMENT"
        )

        section.setObjectName(
            "Section"
        )

        movement_layout.addWidget(
            section
        )

        self.direction_value = QLabel(
            "IDLE"
        )

        self.direction_value.setObjectName(
            "Value"
        )

        movement_layout.addWidget(
            self.direction_value
        )

        self.speed_text = QLabel(
            "Hand speed  •  0.00"
        )

        self.speed_text.setObjectName(
            "Muted"
        )

        movement_layout.addWidget(
            self.speed_text
        )

        self.angle_text = QLabel(
            "Angle  •  0°"
        )

        self.angle_text.setObjectName(
            "Muted"
        )

        movement_layout.addWidget(
            self.angle_text
        )

        movement.setSizePolicy(
            QSizePolicy.Preferred,
            QSizePolicy.Fixed
        )

        side.addWidget(
            movement
        )

        # ----------------------------------------------------
        # GESTURES
        # ----------------------------------------------------

        map_card = QFrame()

        map_card.setObjectName(
            "Surface"
        )

        map_layout = QVBoxLayout(
            map_card
        )

        map_layout.setContentsMargins(
            20,
            20,
            20,
            20
        )

        section = QLabel(
            "GESTURES"
        )

        section.setObjectName(
            "Section"
        )

        map_layout.addWidget(
            section
        )

        mappings = [
            "☝  Index  ·  Move",
            "✌  Two fingers  ·  Scroll",
            "👍  Thumb  ·  Left click",
            "🤙  Pinky  ·  Right click",
            "🤏  Pinch  ·  Drag",
            "✊  Fist  ·  Pause",
            "🖐  Palm  ·  Resume",
        ]

        for text in mappings:

            item = QLabel(
                text
            )

            item.setObjectName(
                "Muted"
            )

            map_layout.addWidget(
                item
            )

        map_card.setSizePolicy(
            QSizePolicy.Preferred,
            QSizePolicy.Fixed
        )

        side.addWidget(
            map_card
        )

        side.addStretch()

        # Put the whole right panel inside a scroll area so no card
        # can overlap or get clipped on smaller screens.
        side_widget = QWidget()
        side_widget.setLayout(side)

        side_scroll = QScrollArea()
        side_scroll.setWidgetResizable(True)
        side_scroll.setFrameShape(QFrame.NoFrame)
        side_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        side_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        side_scroll.setWidget(side_widget)

        side_scroll.setStyleSheet("""
            QScrollArea {
                background: transparent;
                border: none;
            }

            QScrollBar:vertical {
                width: 7px;
                background: transparent;
                margin: 4px 0 4px 0;
            }

            QScrollBar::handle:vertical {
                background: rgba(255, 255, 255, 45);
                border-radius: 3px;
                min-height: 30px;
            }

            QScrollBar::add-line:vertical,
            QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)

        main.addWidget(
            side_scroll,
            3
        )

        root.addLayout(
            main,
            7
        )

        # ====================================================
        # SENSITIVITY
        # ====================================================

        sensitivity = QFrame()

        sensitivity.setObjectName(
            "Surface"
        )

        sensitivity_layout = QVBoxLayout(
            sensitivity
        )

        sensitivity_layout.setContentsMargins(
            24,
            20,
            24,
            22
        )

        top = QHBoxLayout()

        section = QLabel(
            "SENSITIVITY"
        )

        section.setObjectName(
            "Section"
        )

        top.addWidget(
            section
        )

        top.addStretch()

        live = QLabel(
            "LIVE"
        )

        live.setObjectName(
            "Muted"
        )

        top.addWidget(
            live
        )

        sensitivity_layout.addLayout(
            top
        )

        grid = QGridLayout()

        grid.setHorizontalSpacing(
            45
        )

        grid.setVerticalSpacing(
            18
        )

        values = [
            ("Cursor speed", "speed", 100),
            ("Precision", "precision", 70),
            ("Smoothing", "smoothing", 20),
            ("Acceleration", "acceleration", 50),
            ("Dead zone", "dead_zone", 15),
        ]

        positions = [
            (0, 0),
            (0, 1),
            (1, 0),
            (1, 1),
            (2, 0),
        ]

        self.sliders = {}

        for (
            (name, key, default),
            (row, col)
        ) in zip(
            values,
            positions
        ):

            box = QVBoxLayout()

            labels = QHBoxLayout()

            name_label = QLabel(
                name
            )

            name_label.setObjectName(
                "Muted"
            )

            value_label = QLabel(
                str(default)
            )

            value_label.setObjectName(
                "Muted"
            )

            labels.addWidget(
                name_label
            )

            labels.addStretch()

            labels.addWidget(
                value_label
            )

            slider = QSlider(
                Qt.Horizontal
            )

            slider.setRange(
                0,
                100
            )

            slider.setValue(
                default
            )

            slider.valueChanged.connect(
                lambda value,
                key=key,
                label=value_label:
                self.slider_changed(
                    key,
                    value,
                    label
                )
            )

            box.addLayout(
                labels
            )

            box.addWidget(
                slider
            )

            grid.addLayout(
                box,
                row,
                col
            )

            self.sliders[key] = slider

        sensitivity_layout.addLayout(
            grid
        )

        root.addWidget(
            sensitivity
        )

        # ====================================================
        # BOTTOM
        # ====================================================

        bottom = QHBoxLayout()

        self.toggle_button = QPushButton(
            "Enable gesture control"
        )

        self.toggle_button.clicked.connect(
            self.toggle_control
        )

        bottom.addWidget(
            self.toggle_button
        )

        reset = QPushButton(
            "Reset"
        )

        reset.setObjectName(
            "Secondary"
        )

        reset.clicked.connect(
            self.reset_settings
        )

        bottom.addWidget(
            reset
        )

        bottom.addStretch()

        shortcuts = QLabel(
            "Ctrl + Shift + G  ·  Toggle     "
            "Ctrl + Shift + Q  ·  Exit"
        )

        shortcuts.setObjectName(
            "Muted"
        )

        bottom.addWidget(
            shortcuts
        )

        root.addLayout(
            bottom
        )

        # ====================================================
        # SHORTCUTS
        # ====================================================

        toggle_shortcut = QShortcut(
            QKeySequence(
                "Ctrl+Shift+G"
            ),
            self
        )

        toggle_shortcut.activated.connect(
            self.toggle_control
        )

        quit_shortcut = QShortcut(
            QKeySequence(
                "Ctrl+Shift+Q"
            ),
            self
        )

        quit_shortcut.activated.connect(
            self.close
        )

        self.send_settings()

    # ========================================================
    # CAMERA
    # ========================================================

    def update_camera(self, image):

        pixmap = QPixmap.fromImage(
            image
        )

        self.camera_view.setPixmap(
            pixmap.scaled(
                self.camera_view.size(),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
        )

    # ========================================================
    # STATE
    # ========================================================

    def update_state(self, state):

        enabled = state["enabled"]

        if enabled:

            self.status.setText(
                "●  ON"
            )

            self.status.setObjectName(
                "StatusOn"
            )

            self.toggle_button.setText(
                "Disable gesture control"
            )

        else:

            self.status.setText(
                "●  OFF"
            )

            self.status.setObjectName(
                "Status"
            )

            self.toggle_button.setText(
                "Enable gesture control"
            )

        self.status.style().unpolish(
            self.status
        )

        self.status.style().polish(
            self.status
        )

        self.gesture_value.setText(
            state["gesture"]
        )

        confidence = state["confidence"]

        self.confidence.setValue(
            confidence
        )

        self.confidence_text.setText(
            f"Stability  •  {confidence}%"
        )

        self.direction_value.setText(
            state["direction"]
        )

        self.speed_text.setText(
            f"Hand speed  •  {state['speed']:.2f}"
        )

        self.angle_text.setText(
            f"Angle  •  {state['angle']:.0f}°"
        )

    # ========================================================
    # SETTINGS
    # ========================================================

    def slider_changed(
        self,
        key,
        value,
        label
    ):

        label.setText(
            str(value)
        )

        self.send_settings()

    def send_settings(self):

        self.camera.update_settings(
            self.sliders["speed"].value(),
            self.sliders["precision"].value(),
            self.sliders["smoothing"].value(),
            self.sliders["acceleration"].value(),
            self.sliders["dead_zone"].value()
        )

    # ========================================================
    # CONTROL
    # ========================================================

    def toggle_control(self):

        self.camera.set_control(
            not self.camera.enabled
        )

    # ========================================================
    # RESET
    # ========================================================

    def reset_settings(self):

        defaults = {
            "speed": 100,
            "precision": 70,
            "smoothing": 20,
            "acceleration": 50,
            "dead_zone": 15
        }

        for key, value in defaults.items():

            self.sliders[key].setValue(
                value
            )

        self.send_settings()

    # ========================================================
    # CLOSE
    # ========================================================

    def closeEvent(self, event):

        self.camera.running = False

        self.camera.set_control(
            False
        )

        self.camera.wait()

        event.accept()


# ============================================================
# START
# ============================================================

if __name__ == "__main__":

    app = QApplication(
        sys.argv
    )

    app.setStyle(
        "Fusion"
    )

    window = PointlessUI()

    window.show()

    sys.exit(
        app.exec()
    )